import os
import getpass

# Helper functions to read and write files
def read_file(filename):
    if os.path.exists(filename):
        with open(filename, 'r') as file:
            return file.readlines()
    return []

def write_file(filename, lines):
    with open(filename, 'w') as file:
        file.writelines(lines)

# Function to get data as a list from a file
def get_data_list(filename):
    data = []
    lines = read_file(filename)
    for line in lines:
        data.append(line.strip().split(':'))
    return data

# Function to save data list to a file
def save_data_list(filename, data):
    lines = [':'.join(item) + '\n' for item in data]
    write_file(filename, lines)

# Admin credentials
admin_credentials = ['admin', 'admin123']

# Files for storing data
customers_file = 'customers.txt'
transactions_file = 'transactions.txt'
approvals_file = 'approvals.txt'

# Admin functionalities
def admin_menu():
    while True:
        print("\nAdmin Menu")
        print("1. Approve New Customers")
        print("2. View All Customer Profiles")
        print("3. View Specific Customer Profile")
        print("4. View All Transactions of All Customers")
        print("5. View All Transactions of Specific Customer")
        print("6. Logout")
        choice = input("Enter your choice: ")

        if choice == '1':
            approve_customers()
        elif choice == '2':
            view_all_customers()
        elif choice == '3':
            view_specific_customer()
        elif choice == '4':
            view_all_transactions()
        elif choice == '5':
            view_specific_transactions()
        elif choice == '6':
            break
        else:
            print("Invalid choice! Please try again.")

def approve_customers():
    approvals = get_data_list(approvals_file)
    customers = get_data_list(customers_file)

    for approval in approvals.copy():
        username = approval[0]
        details = approval[1:]
        print(f"Username: {username}, Details: {details}")
        approve = input("Approve this customer? (yes/no): ")
        if approve.lower() == 'yes':
            customers.append([username] + details)
            approvals.remove(approval)

    save_data_list(customers_file, customers)
    save_data_list(approvals_file, approvals)
    print("Approval process completed.")

def view_all_customers():
    customers = get_data_list(customers_file)
    for customer in customers:
        print(f"Username: {customer[0]}, Details: {customer[1:]}")

def view_specific_customer():
    username = input("Enter the username of the customer: ")
    customers = get_data_list(customers_file)
    for customer in customers:
        if customer[0] == username:
            print(f"Username: {username}, Details: {customer[1:]}")
            return
    print("Customer not found!")

def view_all_transactions():
    transactions = get_data_list(transactions_file)
    for transaction in transactions:
        print(f"Username: {transaction[0]}, Transactions: {transaction[1:]}")

def view_specific_transactions():
    username = input("Enter the username of the customer: ")
    transactions = get_data_list(transactions_file)
    for transaction in transactions:
        if transaction[0] == username:
            print(f"Username: {username}, Transactions: {transaction[1:]}")
            return
    print("Customer not found!")

# Customer functionalities
def customer_menu(username):
    while True:
        print("\nCustomer Menu")
        print("1. Check Profile")
        print("2. Deposit Money")
        print("3. Withdraw Money")
        print("4. View Transactions")
        print("5. Logout")
        choice = input("Enter your choice: ")

        if choice == '1':
            check_profile(username)
        elif choice == '2':
            deposit_money(username)
        elif choice == '3':
            withdraw_money(username)
        elif choice == '4':
            view_transactions(username)
        elif choice == '5':
            break
        else:
            print("Invalid choice! Please try again.")

def check_profile(username):
    customers = get_data_list(customers_file)
    for customer in customers:
        if customer[0] == username:
            print(f"Username: {username}, Details: {customer[1:]}")
            return
    print("Customer not found!")

def deposit_money(username):
    amount = float(input("Enter amount to deposit: "))
    customers = get_data_list(customers_file)
    transactions = get_data_list(transactions_file)

    for customer in customers:
        if customer[0] == username:
            balance = float(customer[3])
            balance += amount
            customer[3] = str(balance)

            for transaction in transactions:
                if transaction[0] == username:
                    transaction.append(f"Deposit: {amount}")
                    break
            else:
                transactions.append([username, f"Deposit: {amount}"])

            save_data_list(customers_file, customers)
            save_data_list(transactions_file, transactions)
            print(f"Deposited {amount}. New balance: {balance}")
            return
    print("Customer not found!")

def withdraw_money(username):
    amount = float(input("Enter amount to withdraw: "))
    customers = get_data_list(customers_file)
    transactions = get_data_list(transactions_file)

    for customer in customers:
        if customer[0] == username:
            balance = float(customer[3])
            if balance >= amount:
                balance -= amount
                customer[3] = str(balance)

                for transaction in transactions:
                    if transaction[0] == username:
                        transaction.append(f"Withdraw: {amount}")
                        break
                else:
                    transactions.append([username, f"Withdraw: {amount}"])

                save_data_list(customers_file, customers)
                save_data_list(transactions_file, transactions)
                print(f"Withdrew {amount}. New balance: {balance}")
                return
            else:
                print("Insufficient balance!")
                return
    print("Customer not found!")

def view_transactions(username):
    transactions = get_data_list(transactions_file)
    for transaction in transactions:
        if transaction[0] == username:
            print(f"Transactions for {username}: {transaction[1:]}")
            return
    print("Customer not found!")

# Main program
def main():
    while True:
        print("\nBanking Application")
        print("1. Admin Login")
        print("2. Customer Login")
        print("3. Customer Signup")
        print("4. Exit")
        choice = input("Enter your choice: ")

        if choice == '1':
            admin_login()
        elif choice == '2':
            customer_login()
        elif choice == '3':
            customer_signup()
        elif choice == '4':
            break
        else:
            print("Invalid choice! Please try again.")

def admin_login():
    username = input("Enter admin username: ")
    password = getpass.getpass("Enter admin password: ")
    if username == admin_credentials[0] and password == admin_credentials[1]:
        admin_menu()
    else:
        print("Invalid admin credentials!")

def customer_login():
    username = input("Enter username: ")
    password = getpass.getpass("Enter password: ")
    customers = get_data_list(customers_file)
    for customer in customers:
        if customer[0] == username and customer[2] == password:
            customer_menu(username)
            return
    print("Invalid customer credentials or account not approved!")

def customer_signup():
    username = input("Enter new username: ")
    password = getpass.getpass("Enter new password: ")
    name = input("Enter your name: ")
    balance = '0'

    approvals = get_data_list(approvals_file)
    approvals.append([username, name, password, balance])

    save_data_list(approvals_file, approvals)
    print("Signup successful. Please wait for admin approval.")

if __name__ == '__main__':
    main()
